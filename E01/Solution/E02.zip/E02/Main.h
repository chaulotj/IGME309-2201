#ifndef __MAIN_H_
#define __MAIN_H_
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include "GL\glew.h"
#include "GLFW\glfw3.h"
#include "GLM\glm.hpp"
#include "OpenGL-Tutorials\shader.hpp"

#endif //__MAIN_H_
