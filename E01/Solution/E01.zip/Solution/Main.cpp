#include "Main.h"

int main()
{
	std::cout << "Hellow World\n";

	std::cout << "Press enter to finish";
	getchar();
	return 0;
}